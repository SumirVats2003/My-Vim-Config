# Kitty Terminal

https://sw.kovidgoyal.net/kitty/

To install, copy `onehalf-dark.conf` to `~/.config/kitty/onehalf-dark.conf`.

Then, include in the principal configuration file `~/.config/kitty/kitty.conf`:

```
include onehalf-dark.conf
```

Or do the same replacing `onehalf-dark` with `onehalf-light` if you want the light version.
